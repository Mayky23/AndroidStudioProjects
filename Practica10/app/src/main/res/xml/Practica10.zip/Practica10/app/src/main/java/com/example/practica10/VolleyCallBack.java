package com.example.practica10;

import android.content.Context;

import java.util.ArrayList;

public interface VolleyCallBack {
    void onSuccess(Context context, ArrayList<Monumento> monumentos);
}
